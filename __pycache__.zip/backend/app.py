from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/recommend', methods=['POST'])
def recommend_crop():
    data = request.json
    print("Received Data:", data)  # Debugging purpose
    
    # Check if data contains the required keys
    if not data or 'soilType' not in data or 'moistureLevel' not in data:
        return jsonify({"error": "Missing soilType or moistureLevel"}), 400

    soil = data['soilType']
    moisture = data['moistureLevel']

    # AI Logic (Simple Example)
    if soil.lower() == "loamy" and moisture == "high":
        crop = "Rice"
    elif soil.lower() == "clay" and moisture == "medium":
        crop = "Wheat"
    else:
        crop = "Corn"

    return jsonify({"soilType": soil, "moistureLevel": moisture, "recommendedCrop": crop})

if __name__ == '__main__':
    app.run(debug=True)
