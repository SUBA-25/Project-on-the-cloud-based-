fetch('http://127.0.0.1:5000/recommend', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        soilType: "Loamy",
        moistureLevel: "High"
    })
})
.then(response => response.json())
.then(data => console.log("Response from Flask:", data))
.catch(error => console.error("Error:", error));
